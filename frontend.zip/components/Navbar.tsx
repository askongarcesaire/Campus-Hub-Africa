"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

const LIENS = [
  { href: "/fil", label: "Fil d'actualité" },
  { href: "/annuaire", label: "Annuaire" },
  { href: "/messagerie", label: "Messagerie" },
  { href: "/ressources", label: "Ressources" },
];

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();

  function deconnexion() {
    localStorage.removeItem("token");
    localStorage.removeItem("utilisateur");
    router.push("/connexion");
  }

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link href="/fil" className="brand">
          Campus<span>Hub</span> <em>Africa</em>
        </Link>
        <nav className="navbar-links">
          {LIENS.map((lien) => (
            <Link
              key={lien.href}
              href={lien.href}
              className={pathname?.startsWith(lien.href) ? "navbar-link active" : "navbar-link"}
            >
              {lien.label}
            </Link>
          ))}
        </nav>
        <button className="btn-ghost" onClick={deconnexion}>
          Déconnexion
        </button>
      </div>
    </header>
  );
}
