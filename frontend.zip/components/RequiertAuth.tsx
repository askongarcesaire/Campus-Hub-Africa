"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function RequiertAuth({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [pret, setPret] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      router.replace("/connexion");
    } else {
      setPret(true);
    }
  }, [router]);

  if (!pret) return null;
  return <>{children}</>;
}
