"use client";

import { useEffect, useRef, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import RequiertAuth from "@/components/RequiertAuth";
import Navbar from "@/components/Navbar";
import { api } from "@/lib/api";
import { connecterSocket, deconnecterSocket } from "@/lib/socket";
import type { Conversation, MessageChat, Utilisateur } from "@/lib/types";

function MessagerieContenu() {
  const searchParams = useSearchParams();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [interlocuteurId, setInterlocuteurId] = useState<number | null>(
    searchParams.get("utilisateur") ? Number(searchParams.get("utilisateur")) : null
  );
  const [messages, setMessages] = useState<MessageChat[]>([]);
  const [texte, setTexte] = useState("");
  const finListeRef = useRef<HTMLDivElement>(null);

  const moi: Utilisateur | null =
    typeof window !== "undefined"
      ? JSON.parse(localStorage.getItem("utilisateur") || "null")
      : null;

  useEffect(() => {
    api.messages.conversations().then(setConversations).catch(() => {});

    const socket = connecterSocket();
    socket.on("message:nouveau", (message: MessageChat) => {
      setMessages((prev) => {
        const estConversationActive =
          interlocuteurId &&
          (message.expediteur_id === interlocuteurId || message.destinataire_id === interlocuteurId);
        return estConversationActive ? [...prev, message] : prev;
      });
      api.messages.conversations().then(setConversations).catch(() => {});
    });

    return () => {
      deconnecterSocket();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (interlocuteurId) {
      api.messages.historique(interlocuteurId).then(setMessages).catch(() => {});
    }
  }, [interlocuteurId]);

  useEffect(() => {
    finListeRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function envoyer(e: React.FormEvent) {
    e.preventDefault();
    if (!texte.trim() || !interlocuteurId) return;

    const socket = connecterSocket();
    socket.emit("message:envoyer", { destinataire_id: interlocuteurId, contenu: texte.trim() });
    setTexte("");
  }

  return (
    <RequiertAuth>
      <Navbar />
      <main className="page">
        <div className="page-inner">
          <header className="page-head">
            <span className="eyebrow">Communauté</span>
            <h1>Messagerie</h1>
          </header>

          <div className="chat-layout">
            <aside className="chat-sidebar">
              {conversations.map((c) => (
                <button
                  key={c.interlocuteur_id}
                  className={interlocuteurId === c.interlocuteur_id ? "chat-conv chat-conv--active" : "chat-conv"}
                  onClick={() => setInterlocuteurId(c.interlocuteur_id)}
                >
                  <div className="avatar">{c.interlocuteur_nom.charAt(0)}</div>
                  <div className="chat-conv-info">
                    <strong>{c.interlocuteur_nom}</strong>
                    <span>{c.dernier_message}</span>
                  </div>
                  {c.non_lus > 0 && <span className="badge">{c.non_lus}</span>}
                </button>
              ))}
              {conversations.length === 0 && (
                <p className="empty">Aucune conversation. Rends-toi sur l&apos;annuaire pour écrire à un étudiant.</p>
              )}
            </aside>

            <section className="chat-window">
              {interlocuteurId ? (
                <>
                  <div className="chat-messages">
                    {messages.map((m) => (
                      <div
                        key={m.id}
                        className={m.expediteur_id === moi?.id ? "bubble bubble--moi" : "bubble"}
                      >
                        {m.contenu}
                      </div>
                    ))}
                    <div ref={finListeRef} />
                  </div>
                  <form onSubmit={envoyer} className="chat-input-row">
                    <input
                      placeholder="Écris un message..."
                      value={texte}
                      onChange={(e) => setTexte(e.target.value)}
                    />
                    <button className="btn-primary" type="submit">Envoyer</button>
                  </form>
                </>
              ) : (
                <p className="empty">Sélectionne une conversation pour commencer à discuter.</p>
              )}
            </section>
          </div>
        </div>
      </main>
    </RequiertAuth>
  );
}

export default function Messagerie() {
  return (
    <Suspense fallback={null}>
      <MessagerieContenu />
    </Suspense>
  );
}
