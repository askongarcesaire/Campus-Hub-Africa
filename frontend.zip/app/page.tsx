"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function Accueil() {
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem("token");
    router.replace(token ? "/fil" : "/connexion");
  }, [router]);

  return null;
}
