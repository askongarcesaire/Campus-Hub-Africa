import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CampusHub Africa",
  description:
    "Plateforme web communautaire connectant les étudiants d'Afrique francophone : bourses, écoles, logements et stages.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
