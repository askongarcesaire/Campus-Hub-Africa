"use client";

import { useEffect, useState } from "react";
import RequiertAuth from "@/components/RequiertAuth";
import Navbar from "@/components/Navbar";
import { api } from "@/lib/api";
import type { Ressource } from "@/lib/types";

const TYPES: Record<string, string> = {
  cours: "Cours",
  ancien_sujet: "Ancien sujet",
  guide: "Guide",
  autre: "Autre",
};

export default function Ressources() {
  const [liste, setListe] = useState<Ressource[]>([]);
  const [afficherFormulaire, setAfficherFormulaire] = useState(false);
  const [erreur, setErreur] = useState("");
  const [form, setForm] = useState({
    titre: "",
    description: "",
    ecole: "",
    filiere: "",
    type: "cours",
    fichier_url: "",
  });

  async function charger() {
    try {
      setListe(await api.ressources.liste());
    } catch (err: any) {
      setErreur(err.message);
    }
  }

  useEffect(() => {
    charger();
  }, []);

  async function soumettre(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.ressources.creer(form);
      setAfficherFormulaire(false);
      setForm({ titre: "", description: "", ecole: "", filiere: "", type: "cours", fichier_url: "" });
      charger();
    } catch (err: any) {
      setErreur(err.message);
    }
  }

  return (
    <RequiertAuth>
      <Navbar />
      <main className="page">
        <div className="page-inner">
          <header className="page-head">
            <div>
              <span className="eyebrow">Communauté</span>
              <h1>Ressources pédagogiques</h1>
            </div>
            <button className="btn-primary" onClick={() => setAfficherFormulaire(true)}>
              + Partager une ressource
            </button>
          </header>

          {erreur && <div className="alerte-erreur">{erreur}</div>}

          {afficherFormulaire && (
            <div className="modal-backdrop" onClick={() => setAfficherFormulaire(false)}>
              <form className="modal-card" onClick={(e) => e.stopPropagation()} onSubmit={soumettre}>
                <h2>Nouvelle ressource</h2>
                <label>
                  Titre
                  <input required value={form.titre} onChange={(e) => setForm({ ...form, titre: e.target.value })} />
                </label>
                <label>
                  Description
                  <textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                </label>
                <label>
                  École
                  <input value={form.ecole} onChange={(e) => setForm({ ...form, ecole: e.target.value })} />
                </label>
                <label>
                  Filière
                  <input value={form.filiere} onChange={(e) => setForm({ ...form, filiere: e.target.value })} />
                </label>
                <label>
                  Type
                  <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                    <option value="cours">Cours</option>
                    <option value="ancien_sujet">Ancien sujet</option>
                    <option value="guide">Guide</option>
                    <option value="autre">Autre</option>
                  </select>
                </label>
                <label>
                  Lien du fichier (Google Drive, etc.)
                  <input value={form.fichier_url} onChange={(e) => setForm({ ...form, fichier_url: e.target.value })} />
                </label>
                <div className="modal-actions">
                  <button type="button" className="btn-ghost" onClick={() => setAfficherFormulaire(false)}>Annuler</button>
                  <button type="submit" className="btn-primary">Publier</button>
                </div>
              </form>
            </div>
          )}

          <div className="resource-grid">
            {liste.map((r) => (
              <div key={r.id} className="resource-card">
                <span className="tag tag--resource">{TYPES[r.type]}</span>
                <h3>{r.titre}</h3>
                {r.description && <p>{r.description}</p>}
                <div className="resource-meta">
                  {r.ecole && <span>{r.ecole}</span>}
                  {r.filiere && <span>{r.filiere}</span>}
                </div>
                {r.fichier_url && (
                  <a href={r.fichier_url} target="_blank" rel="noopener noreferrer" className="resource-link">
                    Accéder au fichier →
                  </a>
                )}
                <span className="resource-author">Partagé par {r.auteur_nom}</span>
              </div>
            ))}
            {liste.length === 0 && <p className="empty">Aucune ressource partagée pour le moment.</p>}
          </div>
        </div>
      </main>
    </RequiertAuth>
  );
}
