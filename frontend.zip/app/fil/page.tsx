"use client";

import { useEffect, useState } from "react";
import RequiertAuth from "@/components/RequiertAuth";
import Navbar from "@/components/Navbar";
import { api } from "@/lib/api";
import type { Publication } from "@/lib/types";

const CATEGORIES = [
  { valeur: "", label: "Tout" },
  { valeur: "bourse", label: "Bourses" },
  { valeur: "stage", label: "Stages" },
  { valeur: "logement", label: "Logement" },
  { valeur: "general", label: "Général" },
];

const LABEL_CATEGORIE: Record<string, string> = {
  bourse: "Bourse",
  stage: "Stage",
  logement: "Logement",
  general: "Général",
};

export default function Fil() {
  const [publications, setPublications] = useState<Publication[]>([]);
  const [filtre, setFiltre] = useState("");
  const [contenu, setContenu] = useState("");
  const [categorie, setCategorie] = useState("general");
  const [erreur, setErreur] = useState("");

  async function charger(cat = filtre) {
    try {
      const data = await api.publications.liste(cat || undefined);
      setPublications(data);
    } catch (err: any) {
      setErreur(err.message);
    }
  }

  useEffect(() => {
    charger();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function changerFiltre(cat: string) {
    setFiltre(cat);
    charger(cat);
  }

  async function publier(e: React.FormEvent) {
    e.preventDefault();
    if (!contenu.trim()) return;
    try {
      await api.publications.creer(contenu.trim(), categorie);
      setContenu("");
      charger();
    } catch (err: any) {
      setErreur(err.message);
    }
  }

  async function toggleLike(id: number) {
    try {
      await api.publications.liker(id);
      charger();
    } catch (err: any) {
      setErreur(err.message);
    }
  }

  return (
    <RequiertAuth>
      <Navbar />
      <main className="page">
        <div className="page-inner page-inner--narrow">
          <header className="page-head">
            <span className="eyebrow">Communauté</span>
            <h1>Fil d&apos;actualité</h1>
          </header>

          <form onSubmit={publier} className="composer">
            <textarea
              placeholder="Partage une bourse, un stage, un logement ou une info utile..."
              value={contenu}
              onChange={(e) => setContenu(e.target.value)}
              rows={3}
            />
            <div className="composer-actions">
              <select value={categorie} onChange={(e) => setCategorie(e.target.value)}>
                <option value="general">Général</option>
                <option value="bourse">Bourse</option>
                <option value="stage">Stage</option>
                <option value="logement">Logement</option>
              </select>
              <button type="submit" className="btn-primary">Publier</button>
            </div>
          </form>

          {erreur && <div className="alerte-erreur">{erreur}</div>}

          <div className="chip-row">
            {CATEGORIES.map((c) => (
              <button
                key={c.valeur}
                className={filtre === c.valeur ? "chip chip--active" : "chip"}
                onClick={() => changerFiltre(c.valeur)}
              >
                {c.label}
              </button>
            ))}
          </div>

          <div className="post-list">
            {publications.map((p) => (
              <article key={p.id} className="post-card">
                <div className="post-head">
                  <div className="avatar">{p.auteur_nom.charAt(0)}</div>
                  <div>
                    <strong>{p.auteur_nom}</strong>
                    <div className="post-meta">
                      {p.auteur_ecole && <span>{p.auteur_ecole}</span>}
                      <span>{new Date(p.cree_le).toLocaleDateString("fr-FR")}</span>
                    </div>
                  </div>
                  <span className={`tag tag--${p.categorie}`}>{LABEL_CATEGORIE[p.categorie]}</span>
                </div>
                <p className="post-content">{p.contenu}</p>
                <div className="post-actions">
                  <button className="post-action" onClick={() => toggleLike(p.id)}>
                    ♥ {p.nb_likes}
                  </button>
                  <span className="post-action post-action--static">💬 {p.nb_commentaires}</span>
                </div>
              </article>
            ))}
            {publications.length === 0 && <p className="empty">Aucune publication pour le moment.</p>}
          </div>
        </div>
      </main>
    </RequiertAuth>
  );
}
