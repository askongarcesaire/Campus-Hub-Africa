"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import RequiertAuth from "@/components/RequiertAuth";
import Navbar from "@/components/Navbar";
import { api } from "@/lib/api";
import type { Utilisateur } from "@/lib/types";

export default function Annuaire() {
  const [liste, setListe] = useState<Utilisateur[]>([]);
  const [recherche, setRecherche] = useState("");
  const [pays, setPays] = useState("");
  const [erreur, setErreur] = useState("");

  async function charger() {
    try {
      const data = await api.utilisateurs.annuaire({
        q: recherche || undefined,
        pays: pays || undefined,
      });
      setListe(data);
    } catch (err: any) {
      setErreur(err.message);
    }
  }

  useEffect(() => {
    charger();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function rechercher(e: React.FormEvent) {
    e.preventDefault();
    charger();
  }

  return (
    <RequiertAuth>
      <Navbar />
      <main className="page">
        <div className="page-inner">
          <header className="page-head">
            <span className="eyebrow">Communauté</span>
            <h1>Annuaire des étudiants</h1>
          </header>

          <form onSubmit={rechercher} className="search-row">
            <input
              placeholder="Rechercher par nom ou filière..."
              value={recherche}
              onChange={(e) => setRecherche(e.target.value)}
            />
            <input
              placeholder="Pays (ex: Cameroun)"
              value={pays}
              onChange={(e) => setPays(e.target.value)}
            />
            <button className="btn-primary" type="submit">Rechercher</button>
          </form>

          {erreur && <div className="alerte-erreur">{erreur}</div>}

          <div className="directory-grid">
            {liste.map((u) => (
              <Link key={u.id} href={`/messagerie?utilisateur=${u.id}`} className="directory-card">
                <div className="avatar avatar--lg">{u.nom.charAt(0)}</div>
                <strong>{u.nom}</strong>
                <span className="directory-meta">{u.ecole || "École non renseignée"}</span>
                <span className="directory-meta directory-meta--muted">
                  {u.filiere || "Filière non renseignée"} · {u.pays}
                </span>
              </Link>
            ))}
            {liste.length === 0 && <p className="empty">Aucun étudiant trouvé.</p>}
          </div>
        </div>
      </main>
    </RequiertAuth>
  );
}
