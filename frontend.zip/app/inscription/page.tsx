"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "@/lib/api";

export default function Inscription() {
  const [form, setForm] = useState({
    nom: "",
    email: "",
    mot_de_passe: "",
    pays: "",
    ecole: "",
    filiere: "",
    niveau: "",
  });
  const [erreur, setErreur] = useState("");
  const [chargement, setChargement] = useState(false);
  const router = useRouter();

  function majChamp(champ: string, valeur: string) {
    setForm((f) => ({ ...f, [champ]: valeur }));
  }

  async function soumettre(e: React.FormEvent) {
    e.preventDefault();
    setErreur("");
    setChargement(true);
    try {
      const data = await api.auth.inscription(form);
      localStorage.setItem("token", data.token);
      localStorage.setItem("utilisateur", JSON.stringify(data.utilisateur));
      router.push("/fil");
    } catch (err: any) {
      setErreur(err.message);
    } finally {
      setChargement(false);
    }
  }

  return (
    <div className="auth-screen">
      <div className="auth-card auth-card--wide">
        <div className="auth-brand">
          Campus<span>Hub</span> <em>Africa</em>
        </div>
        <p className="auth-sub">Rejoins la communauté étudiante</p>

        <form onSubmit={soumettre} className="auth-form auth-form--grid">
          <label>
            Nom complet
            <input required value={form.nom} onChange={(e) => majChamp("nom", e.target.value)} />
          </label>
          <label>
            Email
            <input required type="email" value={form.email} onChange={(e) => majChamp("email", e.target.value)} />
          </label>
          <label>
            Mot de passe
            <input required type="password" minLength={6} value={form.mot_de_passe} onChange={(e) => majChamp("mot_de_passe", e.target.value)} />
          </label>
          <label>
            Pays
            <input required placeholder="ex: Tchad" value={form.pays} onChange={(e) => majChamp("pays", e.target.value)} />
          </label>
          <label>
            École / Université
            <input value={form.ecole} onChange={(e) => majChamp("ecole", e.target.value)} />
          </label>
          <label>
            Filière
            <input value={form.filiere} onChange={(e) => majChamp("filiere", e.target.value)} />
          </label>
          <label>
            Niveau
            <input placeholder="ex: Licence 3" value={form.niveau} onChange={(e) => majChamp("niveau", e.target.value)} />
          </label>

          {erreur && <div className="alerte-erreur" style={{ gridColumn: "1 / -1" }}>{erreur}</div>}

          <button type="submit" className="btn-primary" style={{ gridColumn: "1 / -1" }} disabled={chargement}>
            {chargement ? "Création..." : "Créer mon compte"}
          </button>
        </form>

        <p className="auth-switch">
          Déjà inscrit ? <Link href="/connexion">Se connecter</Link>
        </p>
      </div>
    </div>
  );
}
