export interface Utilisateur {
  id: number;
  nom: string;
  email: string;
  pays: string;
  ecole: string | null;
  filiere: string | null;
  niveau: string | null;
  bio: string | null;
  avatar_url: string | null;
}

export interface Publication {
  id: number;
  utilisateur_id: number;
  contenu: string;
  categorie: "bourse" | "stage" | "logement" | "general";
  cree_le: string;
  auteur_nom: string;
  auteur_ecole: string | null;
  auteur_avatar: string | null;
  nb_likes: number;
  nb_commentaires: number;
}

export interface Commentaire {
  id: number;
  publication_id: number;
  utilisateur_id: number;
  contenu: string;
  cree_le: string;
  auteur_nom: string;
  auteur_avatar: string | null;
}

export interface MessageChat {
  id: number;
  expediteur_id: number;
  destinataire_id: number;
  contenu: string;
  lu: boolean;
  cree_le: string;
}

export interface Conversation {
  interlocuteur_id: number;
  interlocuteur_nom: string;
  interlocuteur_avatar: string | null;
  dernier_message: string;
  date_dernier_message: string;
  non_lus: number;
}

export interface Ressource {
  id: number;
  utilisateur_id: number;
  titre: string;
  description: string | null;
  ecole: string | null;
  filiere: string | null;
  type: "cours" | "ancien_sujet" | "guide" | "autre";
  fichier_url: string | null;
  cree_le: string;
  auteur_nom: string;
}
