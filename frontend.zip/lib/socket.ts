import { io, Socket } from "socket.io-client";

let socket: Socket | null = null;

export function connecterSocket(): Socket {
  if (socket?.connected) return socket;

  const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;
  socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:4000", {
    auth: { token },
  });
  return socket;
}

export function deconnecterSocket() {
  socket?.disconnect();
  socket = null;
}
