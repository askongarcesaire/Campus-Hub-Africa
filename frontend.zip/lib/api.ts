const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api";

async function requete<T>(chemin: string, options: RequestInit = {}): Promise<T> {
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;

  const reponse = await fetch(`${BASE_URL}${chemin}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  if (reponse.status === 204) return null as T;
  const data = await reponse.json().catch(() => null);

  if (!reponse.ok) {
    throw new Error(data?.erreur || "Une erreur est survenue.");
  }
  return data as T;
}

import type {
  Utilisateur,
  Publication,
  Commentaire,
  Conversation,
  MessageChat,
  Ressource,
} from "./types";

export const api = {
  auth: {
    connexion: (email: string, mot_de_passe: string) =>
      requete<{ token: string; utilisateur: Utilisateur }>("/auth/connexion", {
        method: "POST",
        body: JSON.stringify({ email, mot_de_passe }),
      }),
    inscription: (payload: Record<string, string>) =>
      requete<{ token: string; utilisateur: Utilisateur }>("/auth/inscription", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
  },

  publications: {
    liste: (categorie?: string) =>
      requete<Publication[]>(`/publications${categorie ? `?categorie=${categorie}` : ""}`),
    creer: (contenu: string, categorie: string) =>
      requete<Publication>("/publications", { method: "POST", body: JSON.stringify({ contenu, categorie }) }),
    supprimer: (id: number) => requete<null>(`/publications/${id}`, { method: "DELETE" }),
    liker: (id: number) => requete<{ liked: boolean }>(`/publications/${id}/like`, { method: "POST" }),
    commentaires: (id: number) => requete<Commentaire[]>(`/publications/${id}/commentaires`),
    commenter: (id: number, contenu: string) =>
      requete<Commentaire>(`/publications/${id}/commentaires`, { method: "POST", body: JSON.stringify({ contenu }) }),
  },

  utilisateurs: {
    annuaire: (params: { q?: string; pays?: string; ecole?: string } = {}) => {
      const query = new URLSearchParams(params as Record<string, string>).toString();
      return requete<Utilisateur[]>(`/utilisateurs${query ? `?${query}` : ""}`);
    },
    moi: () => requete<Utilisateur>("/utilisateurs/moi"),
    modifierProfil: (payload: Partial<Utilisateur>) =>
      requete<Utilisateur>("/utilisateurs/moi", { method: "PUT", body: JSON.stringify(payload) }),
  },

  messages: {
    conversations: () => requete<Conversation[]>("/messages/conversations"),
    historique: (utilisateurId: number) => requete<MessageChat[]>(`/messages/${utilisateurId}`),
  },

  ressources: {
    liste: (params: { ecole?: string; filiere?: string; type?: string } = {}) => {
      const query = new URLSearchParams(params as Record<string, string>).toString();
      return requete<Ressource[]>(`/ressources${query ? `?${query}` : ""}`);
    },
    creer: (payload: Partial<Ressource>) =>
      requete<Ressource>("/ressources", { method: "POST", body: JSON.stringify(payload) }),
  },
};
