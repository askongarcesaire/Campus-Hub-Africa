-- CampusHub Africa — Schéma de base de données
-- Exécution : psql -U postgres -d campushub -f database/schema.sql

CREATE TABLE IF NOT EXISTS utilisateurs (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    pays VARCHAR(100) NOT NULL,
    ecole VARCHAR(150),
    filiere VARCHAR(150),
    niveau VARCHAR(50),
    bio TEXT,
    avatar_url TEXT,
    cree_le TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS publications (
    id SERIAL PRIMARY KEY,
    utilisateur_id INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    contenu TEXT NOT NULL,
    categorie VARCHAR(30) NOT NULL DEFAULT 'general'
        CHECK (categorie IN ('bourse', 'stage', 'logement', 'general')),
    cree_le TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS publication_likes (
    publication_id INTEGER NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
    utilisateur_id INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    PRIMARY KEY (publication_id, utilisateur_id)
);

CREATE TABLE IF NOT EXISTS commentaires (
    id SERIAL PRIMARY KEY,
    publication_id INTEGER NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
    utilisateur_id INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    contenu TEXT NOT NULL,
    cree_le TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS messages (
    id SERIAL PRIMARY KEY,
    expediteur_id INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    destinataire_id INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    contenu TEXT NOT NULL,
    lu BOOLEAN NOT NULL DEFAULT FALSE,
    cree_le TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ressources (
    id SERIAL PRIMARY KEY,
    utilisateur_id INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    titre VARCHAR(200) NOT NULL,
    description TEXT,
    ecole VARCHAR(150),
    filiere VARCHAR(150),
    type VARCHAR(30) NOT NULL DEFAULT 'cours'
        CHECK (type IN ('cours', 'ancien_sujet', 'guide', 'autre')),
    fichier_url TEXT,
    cree_le TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_publications_categorie ON publications(categorie);
CREATE INDEX IF NOT EXISTS idx_publications_date ON publications(cree_le DESC);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(expediteur_id, destinataire_id);
CREATE INDEX IF NOT EXISTS idx_utilisateurs_ecole ON utilisateurs(ecole);
CREATE INDEX IF NOT EXISTS idx_utilisateurs_pays ON utilisateurs(pays);
CREATE INDEX IF NOT EXISTS idx_ressources_filiere ON ressources(filiere);
