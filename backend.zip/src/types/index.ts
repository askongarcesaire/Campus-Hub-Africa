export interface Utilisateur {
  id: number;
  nom: string;
  email: string;
  mot_de_passe: string;
  pays: string;
  ecole: string | null;
  filiere: string | null;
  niveau: string | null;
  bio: string | null;
  avatar_url: string | null;
  cree_le: Date;
}

export interface UtilisateurPublic {
  id: number;
  nom: string;
  email: string;
  pays: string;
  ecole: string | null;
  filiere: string | null;
  niveau: string | null;
  bio: string | null;
  avatar_url: string | null;
}

export interface PayloadJWT {
  id: number;
  nom: string;
  email: string;
}

declare global {
  namespace Express {
    interface Request {
      utilisateur?: PayloadJWT;
    }
  }
}
