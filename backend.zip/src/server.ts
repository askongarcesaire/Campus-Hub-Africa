import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import dotenv from "dotenv";

import { verifierToken } from "./middleware/auth";
import { configurerSockets } from "./sockets/chat";

import authRoutes from "./routes/auth";
import publicationsRoutes from "./routes/publications";
import utilisateursRoutes from "./routes/utilisateurs";
import messagesRoutes from "./routes/messages";
import ressourcesRoutes from "./routes/ressources";

dotenv.config();

const app = express();
const httpServer = createServer(app);
const corsOrigin = process.env.CORS_ORIGIN || "*";

const io = new Server(httpServer, {
  cors: { origin: corsOrigin },
});

app.use(cors({ origin: corsOrigin }));
app.use(express.json());

app.get("/api/sante", (req, res) => res.json({ statut: "ok" }));

app.use("/api/auth", authRoutes);
app.use("/api/publications", verifierToken, publicationsRoutes);
app.use("/api/utilisateurs", verifierToken, utilisateursRoutes);
app.use("/api/messages", verifierToken, messagesRoutes);
app.use("/api/ressources", verifierToken, ressourcesRoutes);

app.use((req, res) => res.status(404).json({ erreur: "Route introuvable." }));

configurerSockets(io);

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => {
  console.log(`✔ API CampusHub Africa (REST + Socket.io) sur http://localhost:${PORT}`);
});
