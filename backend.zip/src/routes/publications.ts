import { Router, Request, Response } from "express";
import { pool } from "../db";

const router = Router();

// Fil d'actualité, filtrable par catégorie (?categorie=bourse|stage|logement|general)
router.get("/", async (req: Request, res: Response) => {
  const { categorie } = req.query;
  try {
    const params: any[] = [];
    let requete = `
      SELECT p.*, u.nom AS auteur_nom, u.ecole AS auteur_ecole, u.avatar_url AS auteur_avatar,
        (SELECT COUNT(*)::int FROM publication_likes WHERE publication_id = p.id) AS nb_likes,
        (SELECT COUNT(*)::int FROM commentaires WHERE publication_id = p.id) AS nb_commentaires
      FROM publications p
      JOIN utilisateurs u ON u.id = p.utilisateur_id
    `;
    if (categorie) {
      requete += " WHERE p.categorie = $1";
      params.push(categorie);
    }
    requete += " ORDER BY p.cree_le DESC LIMIT 100";

    const { rows } = await pool.query(requete, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.post("/", async (req: Request, res: Response) => {
  const { contenu, categorie } = req.body;
  if (!contenu) return res.status(400).json({ erreur: "Le contenu est requis." });

  try {
    const { rows } = await pool.query(
      `INSERT INTO publications (utilisateur_id, contenu, categorie)
       VALUES ($1, $2, $3) RETURNING *`,
      [req.utilisateur!.id, contenu, categorie || "general"]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const { rowCount } = await pool.query(
      "DELETE FROM publications WHERE id = $1 AND utilisateur_id = $2",
      [req.params.id, req.utilisateur!.id]
    );
    if (!rowCount) return res.status(404).json({ erreur: "Publication introuvable." });
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

// Like / unlike (bascule)
router.post("/:id/like", async (req: Request, res: Response) => {
  try {
    const { rowCount } = await pool.query(
      "DELETE FROM publication_likes WHERE publication_id = $1 AND utilisateur_id = $2",
      [req.params.id, req.utilisateur!.id]
    );
    if (rowCount) return res.json({ liked: false });

    await pool.query(
      "INSERT INTO publication_likes (publication_id, utilisateur_id) VALUES ($1, $2)",
      [req.params.id, req.utilisateur!.id]
    );
    res.json({ liked: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.get("/:id/commentaires", async (req: Request, res: Response) => {
  try {
    const { rows } = await pool.query(
      `SELECT c.*, u.nom AS auteur_nom, u.avatar_url AS auteur_avatar
       FROM commentaires c JOIN utilisateurs u ON u.id = c.utilisateur_id
       WHERE c.publication_id = $1 ORDER BY c.cree_le ASC`,
      [req.params.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.post("/:id/commentaires", async (req: Request, res: Response) => {
  const { contenu } = req.body;
  if (!contenu) return res.status(400).json({ erreur: "Le contenu est requis." });

  try {
    const { rows } = await pool.query(
      `INSERT INTO commentaires (publication_id, utilisateur_id, contenu)
       VALUES ($1, $2, $3) RETURNING *`,
      [req.params.id, req.utilisateur!.id, contenu]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

export default router;
