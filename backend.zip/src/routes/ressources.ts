import { Router, Request, Response } from "express";
import { pool } from "../db";

const router = Router();

router.get("/", async (req: Request, res: Response) => {
  const { ecole, filiere, type } = req.query;
  try {
    const conditions: string[] = [];
    const params: any[] = [];

    if (ecole) { params.push(ecole); conditions.push(`r.ecole = $${params.length}`); }
    if (filiere) { params.push(filiere); conditions.push(`r.filiere = $${params.length}`); }
    if (type) { params.push(type); conditions.push(`r.type = $${params.length}`); }

    const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const { rows } = await pool.query(
      `SELECT r.*, u.nom AS auteur_nom
       FROM ressources r JOIN utilisateurs u ON u.id = r.utilisateur_id
       ${whereClause} ORDER BY r.cree_le DESC LIMIT 100`,
      params
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.post("/", async (req: Request, res: Response) => {
  const { titre, description, ecole, filiere, type, fichier_url } = req.body;
  if (!titre) return res.status(400).json({ erreur: "Le titre est requis." });

  try {
    const { rows } = await pool.query(
      `INSERT INTO ressources (utilisateur_id, titre, description, ecole, filiere, type, fichier_url)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [req.utilisateur!.id, titre, description || null, ecole || null, filiere || null, type || "cours", fichier_url || null]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const { rowCount } = await pool.query(
      "DELETE FROM ressources WHERE id = $1 AND utilisateur_id = $2",
      [req.params.id, req.utilisateur!.id]
    );
    if (!rowCount) return res.status(404).json({ erreur: "Ressource introuvable." });
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

export default router;
