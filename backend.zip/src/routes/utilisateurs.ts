import { Router, Request, Response } from "express";
import { pool } from "../db";

const router = Router();

// Annuaire — recherche par nom, école, pays ou filière (?q=, ?pays=, ?ecole=)
router.get("/", async (req: Request, res: Response) => {
  const { q, pays, ecole } = req.query;
  try {
    const conditions: string[] = [];
    const params: any[] = [];

    if (q) {
      params.push(`%${q}%`);
      conditions.push(`(nom ILIKE $${params.length} OR filiere ILIKE $${params.length})`);
    }
    if (pays) {
      params.push(pays);
      conditions.push(`pays = $${params.length}`);
    }
    if (ecole) {
      params.push(ecole);
      conditions.push(`ecole = $${params.length}`);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const { rows } = await pool.query(
      `SELECT id, nom, pays, ecole, filiere, niveau, bio, avatar_url
       FROM utilisateurs ${whereClause} ORDER BY nom ASC LIMIT 200`,
      params
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.get("/moi", async (req: Request, res: Response) => {
  try {
    const { rows } = await pool.query(
      "SELECT id, nom, email, pays, ecole, filiere, niveau, bio, avatar_url FROM utilisateurs WHERE id = $1",
      [req.utilisateur!.id]
    );
    if (!rows[0]) return res.status(404).json({ erreur: "Profil introuvable." });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.put("/moi", async (req: Request, res: Response) => {
  const { nom, pays, ecole, filiere, niveau, bio, avatar_url } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE utilisateurs SET
         nom = COALESCE($1, nom), pays = COALESCE($2, pays), ecole = COALESCE($3, ecole),
         filiere = COALESCE($4, filiere), niveau = COALESCE($5, niveau),
         bio = COALESCE($6, bio), avatar_url = COALESCE($7, avatar_url)
       WHERE id = $8
       RETURNING id, nom, email, pays, ecole, filiere, niveau, bio, avatar_url`,
      [nom, pays, ecole, filiere, niveau, bio, avatar_url, req.utilisateur!.id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const { rows } = await pool.query(
      "SELECT id, nom, pays, ecole, filiere, niveau, bio, avatar_url FROM utilisateurs WHERE id = $1",
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ erreur: "Utilisateur introuvable." });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

export default router;
