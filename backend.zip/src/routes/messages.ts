import { Router, Request, Response } from "express";
import { pool } from "../db";

const router = Router();

// Liste des conversations de l'utilisateur (dernier message par interlocuteur)
router.get("/conversations", async (req: Request, res: Response) => {
  try {
    const { rows } = await pool.query(
      `
      SELECT DISTINCT ON (interlocuteur_id)
        interlocuteur_id,
        u.nom AS interlocuteur_nom,
        u.avatar_url AS interlocuteur_avatar,
        m.contenu AS dernier_message,
        m.cree_le AS date_dernier_message,
        (SELECT COUNT(*)::int FROM messages
         WHERE expediteur_id = interlocuteur_id AND destinataire_id = $1 AND lu = FALSE) AS non_lus
      FROM (
        SELECT CASE WHEN expediteur_id = $1 THEN destinataire_id ELSE expediteur_id END AS interlocuteur_id,
               contenu, cree_le
        FROM messages
        WHERE expediteur_id = $1 OR destinataire_id = $1
        ORDER BY cree_le DESC
      ) m
      JOIN utilisateurs u ON u.id = m.interlocuteur_id
      ORDER BY interlocuteur_id, m.cree_le DESC
      `,
      [req.utilisateur!.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

// Historique des messages avec un utilisateur précis
router.get("/:utilisateurId", async (req: Request, res: Response) => {
  try {
    await pool.query(
      "UPDATE messages SET lu = TRUE WHERE expediteur_id = $1 AND destinataire_id = $2",
      [req.params.utilisateurId, req.utilisateur!.id]
    );

    const { rows } = await pool.query(
      `SELECT * FROM messages
       WHERE (expediteur_id = $1 AND destinataire_id = $2) OR (expediteur_id = $2 AND destinataire_id = $1)
       ORDER BY cree_le ASC LIMIT 200`,
      [req.utilisateur!.id, req.params.utilisateurId]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

export default router;
