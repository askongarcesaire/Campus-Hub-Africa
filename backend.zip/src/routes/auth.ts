import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { pool } from "../db";

const router = Router();

router.post("/inscription", async (req: Request, res: Response) => {
  const { nom, email, mot_de_passe, pays, ecole, filiere, niveau } = req.body;

  if (!nom || !email || !mot_de_passe || !pays) {
    return res.status(400).json({ erreur: "Nom, email, mot de passe et pays sont requis." });
  }
  if (mot_de_passe.length < 6) {
    return res.status(400).json({ erreur: "Le mot de passe doit contenir au moins 6 caractères." });
  }

  try {
    const hash = await bcrypt.hash(mot_de_passe, 10);
    const { rows } = await pool.query(
      `INSERT INTO utilisateurs (nom, email, mot_de_passe, pays, ecole, filiere, niveau)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING id, nom, email, pays, ecole, filiere, niveau, bio, avatar_url`,
      [nom, email, hash, pays, ecole || null, filiere || null, niveau || null]
    );

    const utilisateur = rows[0];
    const token = jwt.sign(
      { id: utilisateur.id, nom: utilisateur.nom, email: utilisateur.email },
      process.env.JWT_SECRET as string,
      { expiresIn: "7d" }
    );

    res.status(201).json({ token, utilisateur });
  } catch (err: any) {
    if (err.code === "23505") {
      return res.status(409).json({ erreur: "Cet email est déjà utilisé." });
    }
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

router.post("/connexion", async (req: Request, res: Response) => {
  const { email, mot_de_passe } = req.body;
  if (!email || !mot_de_passe) {
    return res.status(400).json({ erreur: "Email et mot de passe requis." });
  }

  try {
    const { rows } = await pool.query("SELECT * FROM utilisateurs WHERE email = $1", [email]);
    const utilisateur = rows[0];
    if (!utilisateur) {
      return res.status(401).json({ erreur: "Identifiants incorrects." });
    }

    const valide = await bcrypt.compare(mot_de_passe, utilisateur.mot_de_passe);
    if (!valide) {
      return res.status(401).json({ erreur: "Identifiants incorrects." });
    }

    const token = jwt.sign(
      { id: utilisateur.id, nom: utilisateur.nom, email: utilisateur.email },
      process.env.JWT_SECRET as string,
      { expiresIn: "7d" }
    );

    const { mot_de_passe: _, ...utilisateurSansMdp } = utilisateur;
    res.json({ token, utilisateur: utilisateurSansMdp });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erreur: "Erreur serveur." });
  }
});

export default router;
