import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { PayloadJWT } from "../types";

export function verifierToken(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ erreur: "Authentification requise." });
  }

  const token = authHeader.split(" ")[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET as string) as PayloadJWT;
    req.utilisateur = payload;
    next();
  } catch {
    return res.status(401).json({ erreur: "Session invalide ou expirée." });
  }
}

export function verifierTokenSocket(token: string): PayloadJWT | null {
  try {
    return jwt.verify(token, process.env.JWT_SECRET as string) as PayloadJWT;
  } catch {
    return null;
  }
}
