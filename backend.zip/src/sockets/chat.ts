import { Server, Socket } from "socket.io";
import { pool } from "../db";
import { verifierTokenSocket } from "../middleware/auth";

// Associe un utilisateur_id à son (ou ses) socket(s) connecté(s)
const utilisateursConnectes = new Map<number, Set<string>>();

interface EnvoyerMessagePayload {
  destinataire_id: number;
  contenu: string;
}

export function configurerSockets(io: Server) {
  io.use((socket: Socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error("Authentification requise."));

    const payload = verifierTokenSocket(token);
    if (!payload) return next(new Error("Token invalide."));

    (socket as any).utilisateur = payload;
    next();
  });

  io.on("connection", (socket: Socket) => {
    const utilisateur = (socket as any).utilisateur;
    const id = utilisateur.id as number;

    if (!utilisateursConnectes.has(id)) utilisateursConnectes.set(id, new Set());
    utilisateursConnectes.get(id)!.add(socket.id);

    socket.on("message:envoyer", async (payload: EnvoyerMessagePayload) => {
      const { destinataire_id, contenu } = payload;
      if (!contenu?.trim() || !destinataire_id) return;

      try {
        const { rows } = await pool.query(
          `INSERT INTO messages (expediteur_id, destinataire_id, contenu)
           VALUES ($1, $2, $3) RETURNING *`,
          [id, destinataire_id, contenu.trim()]
        );
        const message = rows[0];

        // Confirme l'envoi à l'expéditeur (tous ses onglets/appareils connectés)
        utilisateursConnectes.get(id)?.forEach((socketId) => {
          io.to(socketId).emit("message:nouveau", message);
        });

        // Livre en temps réel au destinataire s'il est connecté
        utilisateursConnectes.get(destinataire_id)?.forEach((socketId) => {
          io.to(socketId).emit("message:nouveau", message);
        });
      } catch (err) {
        console.error("Erreur envoi message :", err);
        socket.emit("message:erreur", { erreur: "Impossible d'envoyer le message." });
      }
    });

    socket.on("typing:debut", (destinataire_id: number) => {
      utilisateursConnectes.get(destinataire_id)?.forEach((socketId) => {
        io.to(socketId).emit("typing:debut", { utilisateur_id: id });
      });
    });

    socket.on("typing:fin", (destinataire_id: number) => {
      utilisateursConnectes.get(destinataire_id)?.forEach((socketId) => {
        io.to(socketId).emit("typing:fin", { utilisateur_id: id });
      });
    });

    socket.on("disconnect", () => {
      utilisateursConnectes.get(id)?.delete(socket.id);
      if (utilisateursConnectes.get(id)?.size === 0) utilisateursConnectes.delete(id);
    });
  });
}
